package PlaceBooking;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/update")
public class UpdateBookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		/*Declare and assign variables to values of Booking.java class*/
		String upid = request.getParameter("bookid");
		String uppickl = request.getParameter("pickloc");
		String updropl = request.getParameter("droploc");
		String uppickd = request.getParameter("pickd");
		String uppickt = request.getParameter("pickt");
		String upndays = request.getParameter("nodays");
		String uptript = request.getParameter("ttype");
		String upcat = request.getParameter("bcatg");
		String upnpass = request.getParameter("nopass");
		String upcont = request.getParameter("ccont");

		Boolean isTrue;
		
		isTrue = BookingDBUtil.updatebooking(upid, uppickl, updropl, uppickd, uppickt, upndays, uptript, upcat, upnpass, upcont);
	
		if (isTrue == true) {
			
			/*Call the method setAttribute to the created object from booking class*/
			List <Booking> bookdetails1 = BookingDBUtil.getBookingDetails(upid);
			request.setAttribute("bookdetails", bookdetails1);
			
			/*This class dispatches the request to UpdateSuccess.jsp page*/
			RequestDispatcher dis = request.getRequestDispatcher("UpdateSuccess.jsp");
			dis.forward(request, response);
		}
		else {
			/*Call the method setAttribute to the created object from booking class*/
			List <Booking> bookdetails1 = BookingDBUtil.getBookingDetails(upid);
			request.setAttribute("bookdetails", bookdetails1);
			
			/*This class dispatches the request to DisplayDetails.jsp page*/
			RequestDispatcher dis = request.getRequestDispatcher("DisplayDetails.jsp");
			dis.forward(request, response);
		}
		
	}

}
