package PlaceBooking;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/insert")
public class BookingInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String pickLoc = request.getParameter("PLoc");
		String dropLoc = request.getParameter("DLoc");
		String pickdate = request.getParameter("PDate");
		String picktime = request.getParameter("PTime");
		String Nodays = request.getParameter("NDays");
		String Triptype = request.getParameter("TType");
		String Category = request.getParameter("Catg");
		String NoPassengers = request.getParameter("NPass");
		String CusContact = request.getParameter("CCont");
		
		Boolean isTrue;
		
		isTrue = BookingDBUtil.InsertBooking(pickLoc, dropLoc, pickdate, picktime, Nodays, Triptype, Category, NoPassengers, CusContact);
		
		if (isTrue == true) {
			
			List <Booking> bookdetails2 = BookingDBUtil.getProfile();
			request.setAttribute("bookdetailspro", bookdetails2);
			
			RequestDispatcher dis = request.getRequestDispatcher("Added.jsp");
			dis.forward(request, response);			
		}
		else {
			RequestDispatcher dis2 = request.getRequestDispatcher("Error.jsp");
			dis2.forward(request, response);			
		}
		
	}

}