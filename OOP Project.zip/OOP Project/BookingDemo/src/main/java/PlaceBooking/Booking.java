package PlaceBooking;

public class Booking {

	private int id;
	private String pickloc;
	private String droploc;
	private String pickdate;
	private String picktime;
	private String nodays;
	private String triptype;
	private String category;
	private String nopassengers;
	private String cuscontact;
	
	public Booking(int id, String pickloc, String droploc, String pickdate, String picktime, String nodays,
			String triptype, String category, String nopassengers, String cuscontact) {
		super();
		this.id = id;
		this.pickloc = pickloc;
		this.droploc = droploc;
		this.pickdate = pickdate;
		this.picktime = picktime;
		this.nodays = nodays;
		this.triptype = triptype;
		this.category = category;
		this.nopassengers = nopassengers;
		this.cuscontact = cuscontact;
	}
	
	public int getId() {
		return id;
	}
	
	public String getPickloc() {
		return pickloc;
	}
	
	public String getDroploc() {
		return droploc;
	}
	
	public String getPickdate() {
		return pickdate;
	}
	
	public String getPicktime() {
		return picktime;
	}
	
	public String getNodays() {
		return nodays;
	}
	
	public String getTriptype() {
		return triptype;
	}
	
	public String getCategory() {
		return category;
	}
	
	public String getNopassengers() {
		return nopassengers;
	}
	
	public String getCuscontact() {
		return cuscontact;
	}
	
}
