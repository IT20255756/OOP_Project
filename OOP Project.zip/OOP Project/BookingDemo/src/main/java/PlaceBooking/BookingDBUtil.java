package PlaceBooking;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;


public class BookingDBUtil {
	
	//Declaration of instance variables
	private static Connection con = null;
	private static Statement stat = null;
	private static ResultSet rs = null;
	
	
	////method to validate booking id
	public static Boolean validate(String bookingId){
		
		
		Boolean isSuccess = false;
		
		//Validate
		try {
			
			con = ConnectionDB.getConnection();
			stat = (Statement) con.createStatement();
			
			//Code a sql query string
			String sql1 = "select * from bookingdetails where BookingID='"+bookingId+"'";
			
			//Execute the query using executeQuery method
			rs = stat.executeQuery(sql1);
			
			if (rs.next()) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			    
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return isSuccess;
	}
	
	//method to insert details
	public static boolean InsertBooking(String PickL, String DropL, String PickD, String PickT, String NoD, String TripT, String catge, String NoP, String CusCont){
		
		Boolean isSuccess = false;
		
		try {
			con = ConnectionDB.getConnection();
			stat = (Statement) con.createStatement();
			
			//Code a sql query string
			String sql = "insert into bookingdetails values (0, '"+PickL+"', '"+DropL+"', '"+PickD+"', '"+PickT+"', '"+NoD+"', '"+TripT+"', '"+catge+"', '"+NoP+"', '"+CusCont+"')";
			
			int i = stat.executeUpdate(sql);
			
			if(i>0) {
				isSuccess = true;
			}
			else{
				isSuccess = false;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
		return isSuccess;
		
	}
	
	//method to update details
	public static boolean updatebooking (String bookid, String pickloc, String droploc, String pickdate, String picktime, String nodays, String triptype, String tripcatg, String npassngers, String cuscont){
		
		Boolean isSuccess = false;
		
		try {
			con = ConnectionDB.getConnection();
			stat = (Statement) con.createStatement();
			
			//Code a sql query string
			String sql = "update bookingdetails set PickLocation='"+pickloc+"', DropLocation='"+droploc+"', PickDate='"+pickdate+"', PickTime='"+picktime+"', NoDays='"+nodays+"',TripType='"+triptype+"', Category='"+tripcatg+"', NoPassengers='"+npassngers+"', CusContact='"+cuscont+"' "
						+ "where BookingID='"+bookid+"'";
			
			int a = stat.executeUpdate(sql);
			
			if(a>0){
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
		
		return isSuccess;
	
	}
	
	//method to retrieve details
	public static List<Booking> getBookingDetails(String id){
		
		int convertedID = Integer.parseInt(id);
		
		ArrayList<Booking> book = new ArrayList<>();
		
		try {
			
			con = ConnectionDB.getConnection();
			stat = (Statement) con.createStatement();
			
			//Code a sql query string
			String sql = "select * from bookingdetails where BookingID='"+convertedID+"' ";
			
			rs = stat.executeQuery(sql);
			
			//repeated process for each row
			while(rs.next()) {
				int Rebookid = rs.getInt(1);
				String Repickloc = rs.getString(2);
				String Redroploc = rs.getString(3);
				String Repickdate = rs.getString(4);
				String Repicktime = rs.getString(5);
				String Renodays = rs.getString(6);
				String Retriptype = rs.getString(7);
				String Recategory = rs.getString(8);
				String Renopassengers = rs.getString(9);
				String Recuscontact = rs.getString(10);
				
				Booking b = new Booking(Rebookid, Repickloc, Redroploc, Repickdate, Repicktime, Renodays, Retriptype, Recategory, Renopassengers, Recuscontact);
			
				book.add(b);
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return book;
		
	}
//method to retrieve details	
public static List<Booking> getProfile(){
		
		ArrayList<Booking> prof = new ArrayList<>();
		
		try {
			
			con = ConnectionDB.getConnection();
			stat = (Statement) con.createStatement();
			
			//Code a sql query string
			String sql = "select * from bookingdetails where BookingID=(Select max(BookingID) from bookingdetails)";
			
			rs = stat.executeQuery(sql);
			
			while(rs.next()) {
				int Rebookid = rs.getInt(1);
				String Repickloc = rs.getString(2);
				String Redroploc = rs.getString(3);
				String Repickdate = rs.getString(4);
				String Repicktime = rs.getString(5);
				String Renodays = rs.getString(6);
				String Retriptype = rs.getString(7);
				String Recategory = rs.getString(8);
				String Renopassengers = rs.getString(9);
				String Recuscontact = rs.getString(10);
				
				Booking p = new Booking(Rebookid, Repickloc, Redroploc, Repickdate, Repicktime, Renodays, Retriptype, Recategory, Renopassengers, Recuscontact);
			
				prof.add(p);
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return prof;
		
	}
	
	//method for deletion
	public static boolean deleteBooking(String id) {
		
		boolean isSuccess = false;
		
		int convertedID = Integer.parseInt(id);
		
		try {
			
			con = ConnectionDB.getConnection();
			stat = (Statement) con.createStatement();
			
			//Code a sql query string
			String sql = "delete from bookingdetails where BookingID='"+convertedID+"' ";
			
			int rsd = stat.executeUpdate(sql);
			
			if(rsd>0) {
				isSuccess = true;
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return isSuccess;
	}
	
}

