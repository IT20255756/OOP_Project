package PlaceBooking;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionDB {

    private static String url = "jdbc:mysql://localhost:3306/transport_db";
    private static String user = "root";
    private static String password = "#Group20";
    private static Connection con;
    
    // This works according to singleton pattern
    private ConnectionDB() {
    	
    }
    
    public static Connection getConnection() throws SQLException {
        
        Object connect = null;
        
		if (connect == null || ((Connection) connect).isClosed()) {

            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(url, user, password);
            }
            catch(Exception e)
            {
                System.out.println("DB Connection is Failed!");
            }
            
        }        
        
        return con;
        
    }    
    
}