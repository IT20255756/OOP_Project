package PlaceBooking;

public class Categories {
	
	private int cid;
	private String cname;
	private String cVehicle;
	private String cMaxPass;
	private String cCost;

	public Categories(int cid, String cname, String cVehicle, String cMaxPass, String cCost) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.cVehicle = cVehicle;
		this.cMaxPass = cMaxPass;
		this.cCost = cCost;
	}
	
	public int getCid() {
		return cid;
	}
	
	public String getCname() {
		return cname;
	}
	
	public String getcVehicle() {
		return cVehicle;
	}
	
	public String getcMaxPass() {
		return cMaxPass;
	}
	
	public String getcCost() {
		return cCost;
	}
	
}
